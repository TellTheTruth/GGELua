
local g精灵 = require "gge精灵类"
local g纹理 = require "gge纹理类"
local g文字 = require "gge文字类"
local fmod = require "FMOD类"
require "gge函数"

引擎.创建("Galaxy2D Game Engine  洗脑中...",800,600,100)
引擎.垂直同步(true)
logo = g精灵(g纹理("../res/logo.png"))
logo:置中心(300,300)
font = g文字("c:\\windows\\fonts\\simkai.ttf",20)

f = fmod("../res/小苹果.mp3",true,true)
rad = 0
r,g,b=0,0,0
循环 = true

function 渲染函数()
	引擎.渲染开始()
	引擎.渲染清除(0xFF808080)
	rad =rad+0.1
	if rad>360 then rad=0 end
	
	if 循环 then 
		r,g,b = r+1,g+1,b+1
		if r>255 then 循环 = false;r=255 end
	else
		r,g,b = r-1,g-1,b-1
		if r<0 then 循环 = true;r=0 end
	end
	logo:置颜色(RGB(r,g,b))
	logo:置坐标_高级(400,300,math.rad(rad))
	logo:显示()
	font:显示(10,10,string.format("FPS:%d",引擎.取FPS()))
	引擎.渲染结束()
end

